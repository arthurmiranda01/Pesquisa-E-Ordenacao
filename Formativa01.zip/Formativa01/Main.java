public class Main {
    public static void main(String[] args) {
        // Criando a lista encadeada de livros
        LinkedList library = new LinkedList();

        // Adicionando alguns livros
        library.addBook(new Book("O Senhor dos Anéis", "J.R.R. Tolkien", 1954));
        library.addBook(new Book("Berserk", "Kentauro Miura", 1981));
        library.addBook(new Book("Harry Potter", "J.K Rowling", 1998));

        // Exibindo todos os livros
        System.out.println("Coleção de Livros:");
        library.displayBooks();

        // Buscando um livro por título
        String titleToSearch = "Berserk";
        Book book = library.searchByTitle(titleToSearch);
        if (book != null) {
            System.out.println("\nLivro encontrado: " + book);
        } else {
            System.out.println("\nLivro não encontrado: " + titleToSearch);
        }

        // Removendo um livro por título
        String titleToRemove = "O Senhor dos Anéis";
        if (library.removeByTitle(titleToRemove)) {
            System.out.println("\nLivro removido com sucesso: " + titleToRemove);
        } else {
            System.out.println("\nLivro não encontrado para remoção: " + titleToRemove);
        }

        // Exibindo a lista após a remoção
        System.out.println("\nColeção de Livros Atualizada:");
        library.displayBooks();
    }
}