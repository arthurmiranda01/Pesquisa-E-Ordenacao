public class Node {
    Book book;  // O livro armazenado no nó
    Node next;  // Ponteiro para o próximo nó na lista

    // Construtor
    public Node(Book book) {
        this.book = book;
        this.next = null; // Inicialmente, o próximo nó é null
    }
}
