public class LinkedList {
    private Node head;  // Cabeça da lista, começa como null

    // Construtor
    public LinkedList() {
        this.head = null;
    }

    // Adiciona um livro na lista
    public void addBook(Book book) {
        Node newNode = new Node(book);  // Cria um novo nó com o livro
        if (head == null) {
            head = newNode;  // Se a lista estiver vazia, o novo nó será a cabeça
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;  // Vai até o último nó
            }
            current.next = newNode;  // Adiciona o novo nó ao final da lista
        }
    }

    // Exibe todos os livros da lista
    public void displayBooks() {
        if (head == null) {
            System.out.println("A lista de livros está vazia.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.println(current.book);  // Exibe as informações do livro
            current = current.next;  // Vai para o próximo nó
        }
    }

    // Pesquisa um livro por título
    public Book searchByTitle(String title) {
        Node current = head;
        while (current != null) {
            if (current.book.getTitle().equalsIgnoreCase(title)) {
                return current.book;  // Retorna o livro encontrado
            }
            current = current.next;
        }
        return null;  // Se não encontrar, retorna null
    }

    // Remove um livro por título
    public boolean removeByTitle(String title) {
        if (head == null) {
            return false;  // Lista vazia
        }
        if (head.book.getTitle().equalsIgnoreCase(title)) {
            head = head.next;  // Remove o primeiro nó
            return true;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.book.getTitle().equalsIgnoreCase(title)) {
                current.next = current.next.next;  // Remove o nó
                return true;
            }
            current = current.next;
        }
        return false;  // Não encontrou o livro
    }
}