public class BinaryTree {
    private Node root;

    public BinaryTree() {
        root = null;
    }

    // Método para inserir um livro na árvore binária
    public void inserir(Livro livro) {
        root = inserir(root, livro);
    }

    private Node inserir(Node node, Livro livro) {
        // Caso base: posição encontrada para inserir o novo nó
        if (node == null) {
            return new Node(livro);
        }

        // Comparando o título dos livros para decidir a posição
        if (livro.getTitulo().compareTo(node.getLivro().getTitulo()) < 0) {
            node.setEsquerdo(inserir(node.getEsquerdo(), livro));
        } else if (livro.getTitulo().compareTo(node.getLivro().getTitulo()) > 0) {
            node.setDireito(inserir(node.getDireito(), livro));
        }

        return node;
    }

    // Método para buscar um livro pelo título
    public Livro buscar(String titulo) {
        return buscar(root, titulo);
    }

    private Livro buscar(Node node, String titulo) {
        if (node == null) {
            return null;
        }

        // Se o título for encontrado
        if (titulo.equals(node.getLivro().getTitulo())) {
            return node.getLivro();
        }

        // Se o título for menor que o do nó atual, buscar à esquerda
        if (titulo.compareTo(node.getLivro().getTitulo()) < 0) {
            return buscar(node.getEsquerdo(), titulo);
        }

        // Se o título for maior que o do nó atual, buscar à direita
        return buscar(node.getDireito(), titulo);
    }

    // Método para listar todos os livros em ordem (in-order traversal)
    public void listar() {
        listar(root);
    }

    private void listar(Node node) {
        if (node != null) {
            listar(node.getEsquerdo());
            System.out.println(node.getLivro());
            listar(node.getDireito());
        }
    }
}
