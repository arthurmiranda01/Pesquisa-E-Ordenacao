import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Grafo {
    private Map<Livro, Set<Livro>> grafo;

    public Grafo() {
        grafo = new HashMap<>();
    }

    public void adicionarLivro(Livro livro) {
        grafo.putIfAbsent(livro, new HashSet<>());
    }

    public void adicionarRelacao(Livro livro, Livro livroRelacionado) {
        grafo.putIfAbsent(livro, new HashSet<>());
        grafo.putIfAbsent(livroRelacionado, new HashSet<>());
        grafo.get(livro).add(livroRelacionado);
    }

    public Set<Livro> recomendarLivros(Livro livro) {
        return grafo.getOrDefault(livro, new HashSet<>());
    }

    public void exibirRecomendacoes() {
        for (Map.Entry<Livro, Set<Livro>> entry : grafo.entrySet()) {
            System.out.println("Livro: " + entry.getKey());
            System.out.println("Recomendações:");
            for (Livro recomendado : entry.getValue()) {
                System.out.println("  - " + recomendado);
            }
            System.out.println();
        }
    }
}



