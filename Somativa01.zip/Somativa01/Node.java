public class Node {
    Book book;
    Node next;

    // Construtor
    public Node(Book book) {
        this.book = book;
        this.next = null;
    }
}
