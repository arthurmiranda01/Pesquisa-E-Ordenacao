public class Stack {
    private Node top;

    public Stack() {
        this.top = null;
    }

    public void push(Book book) {
        Node newNode = new Node(book);
        newNode.next = top;
        top = newNode;
    }

    public Book pop() {
        if (top == null) {
            return null; // Pilha vazia
        }
        Book book = top.book;
        top = top.next;
        return book;
    }

    public void displayStack() {
        if (top == null) {
            System.out.println("O histórico está vazio.");
            return;
        }
        Node current = top;
        while (current != null) {
            System.out.println(current.book);
            current = current.next;
        }
    }
}

