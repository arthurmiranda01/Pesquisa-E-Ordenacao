public class Main {
    public static void main(String[] args) {
        // Biblioteca com livros
        LinkedList library = new LinkedList();
        library.addBook(new Book("O Senhor dos Anéis", "J.R.R. Tolkien", 1954));
        library.addBook(new Book("Berserk", "Kentauro Miura", 1981));
        library.addBook(new Book("Harry Potter", "J.K Rowling", 1998));

        // Lista de espera (Fila)
        Queue waitingList = new Queue();
        waitingList.enqueue(new Book("O Senhor dos Anéis", "J.R.R. Tolkien", 1954));
        waitingList.enqueue(new Book("Berserk", "Kentauro Miura", 1981));

        // Histórico de navegação (Pilha)
        Stack navigationHistory = new Stack();
        navigationHistory.push(new Book("Harry Potter", "J.K Rowling", 1998));

        // Exibir livros na biblioteca
        System.out.println("Coleção de Livros:");
        library.displayBooks();

        // Exibir fila de espera
        System.out.println("\nLista de Espera (Fila):");
        waitingList.displayQueue();

        // Exibir histórico de navegação
        System.out.println("\nHistórico de Navegação (Pilha):");
        navigationHistory.displayStack();

        // Simulando a visualização de um livro
        String titleToSearch = "Berserk";
        Book book = library.searchByTitle(titleToSearch);
        if (book != null) {
            System.out.println("\nLivro encontrado: " + book);
            navigationHistory.push(book); // Adiciona o livro ao histórico
        } else {
            System.out.println("\nLivro não encontrado: " + titleToSearch);
        }

        // Simulando a remoção de um livro da biblioteca
        String titleToRemove = "O Senhor dos Anéis";
        if (library.removeByTitle(titleToRemove)) {
            System.out.println("\nLivro removido com sucesso: " + titleToRemove);
        } else {
            System.out.println("\nLivro não encontrado para remoção: " + titleToRemove);
        }

        // Exibir lista de livros atualizada
        System.out.println("\nColeção de Livros Atualizada:");
        library.displayBooks();
    }
}
