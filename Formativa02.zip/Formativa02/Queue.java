public class Queue {
    private Node front;
    private Node rear;

    public Queue() {
        this.front = null;
        this.rear = null;
    }

    public void enqueue(Book book) {
        Node newNode = new Node(book);
        if (rear == null) {
            front = rear = newNode;
            return;
        }
        rear.next = newNode;
        rear = newNode;
    }

    public Book dequeue() {
        if (front == null) {
            return null; // Fila vazia
        }
        Book book = front.book;
        front = front.next;
        if (front == null) {
            rear = null; // Fila ficou vazia
        }
        return book;
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void displayQueue() {
        if (isEmpty()) {
            System.out.println("A lista de espera está vazia.");
            return;
        }
        Node current = front;
        while (current != null) {
            System.out.println(current.book);
            current = current.next;
        }
    }
}

