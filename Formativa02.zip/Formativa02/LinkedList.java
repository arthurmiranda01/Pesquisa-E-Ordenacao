public class LinkedList {
    private Node head;

    public LinkedList() {
        this.head = null;
    }

    public void addBook(Book book) {
        Node newNode = new Node(book);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void displayBooks() {
        if (head == null) {
            System.out.println("A lista de livros está vazia.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.println(current.book);
            current = current.next;
        }
    }

    public Book searchByTitle(String title) {
        Node current = head;
        while (current != null) {
            if (current.book.getTitle().equalsIgnoreCase(title)) {
                return current.book;
            }
            current = current.next;
        }
        return null;
    }

    public boolean removeByTitle(String title) {
        if (head == null) {
            return false;
        }
        if (head.book.getTitle().equalsIgnoreCase(title)) {
            head = head.next;
            return true;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.book.getTitle().equalsIgnoreCase(title)) {
                current.next = current.next.next;
                return true;
            }
            current = current.next;
        }
        return false;
    }
}